package Project2;

public class Main {

	public static void main(String args[]) {
		Report obj = new Report();
		obj.loadData();
		obj.scores();
		obj.maxsp();
		obj.maxlp();
		obj.maxscore();
		obj.maxart();
		obj.maxathletic();
		obj.top();
	}
	
}
